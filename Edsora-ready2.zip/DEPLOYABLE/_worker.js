// Backend moved to /worker.js (not served publicly).
